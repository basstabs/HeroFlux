export const CONST_GAME_CONTAINER = "game-container";
export const CONST_UI_CONTAINER = "ui-layer";

export const CONST_UI_WIDTH = 3840;
export const CONST_UI_HEIGHT = 2160;

export const CONST_POOL_LOCATION_X = -1000; //The location where we set unused pool objects
export const CONST_POOL_LOCATION_Y = -1000;